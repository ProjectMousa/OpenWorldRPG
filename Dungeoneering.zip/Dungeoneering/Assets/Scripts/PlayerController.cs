﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerController : MonoBehaviour
{

    // Use this for initialization

    GameObject player;
    private float playerSpeed = 5.0f;
    private Animator playerAnim;
    private bool playerFacingRight = true;
    private bool isMale = true;

    void Start()
    {
        player = GameObject.Find("Player");
        playerAnim = player.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButton("Vertical"))
        {
            player.transform.position = new Vector3(player.transform.position.x, player.transform.position.y + (Input.GetAxis("Vertical") * playerSpeed * Time.deltaTime), player.transform.position.z);
        }
        if (Input.GetButton("Horizontal"))
        {
            player.transform.position = new Vector3(player.transform.position.x + (Input.GetAxis("Horizontal") * playerSpeed * Time.deltaTime), player.transform.position.y, player.transform.position.z);
        }
        SetMovementAnimation();
    }

    void SetMovementAnimation()
    {
        if (isMale == true)
        {
            playerAnim.SetBool("IsMale", true);
        }
        else
        {
            playerAnim.SetBool("IsMale", false);
        }

        float speedX = Input.GetAxis("Horizontal");
        float speedY = Input.GetAxis("Vertical");
        float speed = Mathf.Sqrt(Mathf.Pow(speedX, 2) + Mathf.Pow(speedY, 2));
        playerAnim.SetFloat("Speed", Mathf.Abs(speed));

        if (Mathf.Abs(speedY) >= Mathf.Abs(speedX))
        {
            if (speedY > 0)
            {
                playerAnim.SetBool("WalkUp", true);
                playerAnim.SetBool("WalkDown", false);
                playerAnim.SetBool("WalkSide", false);
            }
            else
            {
                playerAnim.SetBool("WalkUp", false);
                playerAnim.SetBool("WalkDown", true);
                playerAnim.SetBool("WalkSide", false);
            }
        }
        else
        {
            if (speedX > 0)
            {
                player.transform.localScale = new Vector3(-1, player.transform.localScale.y, player.transform.localScale.z);
            }
            else
            {
                player.transform.localScale = new Vector3(1, player.transform.localScale.y, player.transform.localScale.z);
            }
            playerAnim.SetBool("WalkUp", false);
            playerAnim.SetBool("WalkDown", false);
            playerAnim.SetBool("WalkSide", true);
        }
    }
}
